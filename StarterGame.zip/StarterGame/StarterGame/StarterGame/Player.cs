﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    public class Player
    {
        public float playerHp = 100f;
        public int playerAttack = 5;
        public int playerDefence = 1;
        public GameState curState;

        public int Defence()
        {
            if (playerDefence <= 100)
            {
                return playerDefence;
            }
            else
            {
                return 0;
            }
        }
        public bool isTurn = true;
        public bool isDead()
        {
            if (playerHp > 0)
                return false;
            else
                return true;
        }


        private Room _currentRoom = null;
        private IItem _inventory = null;
        public Room CurrentRoom
        {
            get
            {
                return _currentRoom;
            }
            set
            {
                _currentRoom = value;
            }
        }

        public Player(Room room)
        {
            _currentRoom = room;
            _inventory = new ItemContainer("Inventory", 0f, "We keep our items here.");
        }

        public void WaltTo(string direction)
        {
            Door door = this._currentRoom.GetExit(direction);
            if (door != null)
            {
                if (door.HasCombat)
                {
                    curState =  GameState.Combat;

                }
                if (door.IsOpen)
                {
                    Room nextRoom = door.OtherSideRoom(CurrentRoom);
                    Notification notification = new Notification("PlayerWillEnterRoom");
                    NotificationCenter.Instance.PostNotification(notification);
                    this._currentRoom = nextRoom;
                    notification = new Notification("PlayerDidEnterRoom");
                    NotificationCenter.Instance.PostNotification(notification);
                    this.OutputMessage("\n" + this._currentRoom.Description());
                }
                else
                {
                    WarningMessage("\nThe door on" + direction + "is closed");
                }
             
            }
            else
            {
                this.ErrorMessage("\nThere is no door on " + direction);
            }
        }
        public void Give(IItem item)
        {
            _inventory.AddItem(item);
        }
        public IItem Take(string itemName)
        {
            IItem item = _inventory.RemoveItem(itemName);
            return item;
        }
        public void Drop(string itemName)
        {
            IItem item = Take(itemName);
            if (item != null)
            {
                CurrentRoom.Drop(item);
                InfoMessage("You dropped the " + itemName + " in the room");
            }
            else
            {
                ErrorMessage("The item named " + itemName + "is not in the inventory");
            }
        }
        public void Pickup(string itemName)
        {
            IItem item = CurrentRoom.Pickup(itemName);
            if (item != null)
            {
                Give(item);
                InfoMessage("You picked up the " + itemName + " from the room");
            }
            else
            {
                ErrorMessage("The item named " + itemName + "is not in the room");
            }
        }
        public void Invetory()
        {
            InfoMessage(_inventory.Description);
        }
        public void Inspect(string itemName)
        {
            IItem item = CurrentRoom.Pickup(itemName);
            if (item != null)
            {
                InfoMessage("Item " + itemName + " Stats" + item.Description);
                CurrentRoom.Drop(item);
            }
            else
            {
                ErrorMessage("The item " + itemName + "is not in the room.");
            }
        }
        public void Open(string direction)
        {
            Door door = this.CurrentRoom.GetExit(direction);
            if (door != null)
            {
                if (door.IsOpen)
                {
                    WarningMessage("\nDoor on\n" + direction + "is already open");
                }
                else
                {
                    door.open();
                    InfoMessage("\nDoor on\n" + direction + "is now open");
                }
            }
            else
            {
                this.ErrorMessage("\nThere is no door on" + direction);
            }
        }
        public void Close(string direction)
        {
            Door door = this.CurrentRoom.GetExit(direction);
            if (door != null)
            {
                if (door.IsClosed)
                {
                    WarningMessage("\nDoor on\n" + direction + "is already closed");
                }
                else
                {
                    door.close();
                    InfoMessage("\nDoor on\n" + direction + "is now closed");
                }
            }
            else
            {
                this.ErrorMessage("\nThere is no door on" + direction);
            }
        }

        public void OutputMessage(string message)
        {
            Console.WriteLine(message);
        }
        public void ColoredMessage(string message, ConsoleColor color)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            OutputMessage(message);
            Console.ForegroundColor = oldColor;
        }
        public void ErrorMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.Red);
        }
        public void WarningMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.Yellow);
        }
        public void InfoMessage(string message)
        {
            ColoredMessage(message, ConsoleColor.Cyan);
        }
    }

}
