﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    public enum GameState { Noncombat, Combat, GameOVer }
    public class Game
    {
        Player player;
        Parser parser;
        bool playing;
        GameClock gameClock;
        int timeIsUp;
        public GameState _currentState;

        public Game()
        {
            playing = false;
            parser = new Parser(new CommandWords());
            player = new Player(CreateWorld());
            gameClock = new GameClock(1000);
            timeIsUp = 30;
            NotificationCenter.Instance.AddObserver("GameClockTick", ProcessClockTick);
            Console.ForegroundColor = ConsoleColor.Green;
            _currentState = GameState.Noncombat;

        }

        public Room CreateWorld()
        {
            // Room 'name' = new Room("Discription");
            Room startRoom = new Room("A small cramp room with dusty books litering the room");
            Room darkRoom = new Room("A dark room that you can not see much detail");
            Room trapRoom = new Room("outside the game realm");
            Room lootRoom = new Room("There's loot in this room");

            // Door door = Door.CreateDoor(Room room1, Room room2, String label1, String label2)
            Door door = Door.CreateDoor(startRoom, darkRoom, "north", "south");
            door.close();
            door.combat();
            door = Door.CreateDoor(startRoom, trapRoom, "east", "west");
            door.close();
            door = Door.CreateDoor(startRoom, lootRoom, "west", "east");
            door.open();
            IItem item = new Item("sword", 1.1f, "Magical sword of destiny!");
            startRoom.Drop(item);
            IItem itemContainer = new ItemContainer();
            IItem itemForContainer = new Item("God Seed - Red", 2f);
            itemContainer.AddItem(itemForContainer);
            lootRoom.Drop(itemContainer);
            IMonster skeleton = new Monster("Skeleton", 10, 12, 2, 5, "The pile of bones suddenly stirs, rising up to take on a human shape.Its long, bony fingers reach out to claw at the living. ");
            darkRoom.addMonster(skeleton);
            IMonster nomonster = new Monster("nothing", 0, 0, 0, 0, "No monsters here");
            startRoom.addMonster(nomonster);
            return startRoom;
        }

        /**
     *  Main play routine.  Loops until end of play.
     */
        public void Play()
        {

            // Enter the main command loop.  Here we repeatedly read commands and
            // execute them until the game is over.

            bool finished = false;
            while (!finished && playing)
            {
                Console.Write("\n>");
                Command command = parser.ParseCommand(Console.ReadLine());
                if (command == null)
                {
                    Console.WriteLine("I don't understand...");
                }
                else
                {
                    finished = command.Execute(player);
                }
            }
        }


        public void Start()
        {
            playing = true;
            _currentState = GameState.Noncombat;
            player.OutputMessage(Welcome());
        }
    
        public void End()
        {
            playing = false;
            player.OutputMessage(Goodbye());
        }

        public string Welcome()
        {
            return "Welcome to GodSeed! A rogue-like dungeon crawler." + player.CurrentRoom.Description();
        }

        public string Goodbye()
        {
            return "\nThank you for playing, Goodbye. \n";
        }
        public void ProcessClockTick(Notification notification) 
        {
            timeIsUp--;
            if (timeIsUp == 0)
            {
                /*Console.WriteLine("You ran out of time. Good luck next time!");
                playing = false;*/
            }
        }
    }
}
