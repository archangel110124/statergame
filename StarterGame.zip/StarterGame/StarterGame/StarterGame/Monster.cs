﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public interface IMonster
    {
        string Name { get; }
        int Health { get; set; }
        int Defense { get; set; }
        int Attack { get; set; }
        int Damage { get; set; }
        string Description { get; set; }
        void AddMonster(IMonster monster);
    }
    
    public class Monster : IMonster
    {
        public string _name;
        private Dictionary<string, IItem> _monsters;
        public string Name
        {
            get
            {
                string monsterList = "monsters: ";
                foreach (Monster monster in _monsters.Values)
                {
                    monsterList += "\n" + monster.Description;
                }
                return "\nName: " + Name + "\nName: " + _name + "Description: " + Description;
            }
        }
        public int Health { get; set; }
        public int Defense { get; set; }
        public int Attack { get; set; }
        public int Damage { get; set; }
        public string Description { get; set; } 
        public Monster(string name, int health, int defense, int attack, int damage, string description)
        {
            _name = name;
            Health = health;
            Defense = defense;
            Attack = attack;
            Damage = damage;
            Description = description;
        }
        public void AddMonster(IMonster monster)
        {

        }
    } 
}
