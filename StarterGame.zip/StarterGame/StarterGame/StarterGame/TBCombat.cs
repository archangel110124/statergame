﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public class TBCombat
    { 
        public enum CombatState { PlayerTurn, EnemyTurn, Battleover }    
        public CombatState curState;
        public GameState curGameState;
        public IMonster monsterStats;
        public Player playerHp;
        private Dictionary<int, Monster> _monsterStatList;
        public String MonsterStats
        {
            get
            {
                String tempString = "";
                foreach (Monster monsterStats in _monsterStatList.Values)
                {
                    tempString += monsterStats + "\n";
                }
                return tempString;
            }
        }

        void Update()
        {
            bool working = false;
            string choice = "";
            if (curGameState == GameState.Combat)
            {
                working = true;
            }
            switch (curState)
            {
                case CombatState.PlayerTurn:


                    while (working)
                    {
                        Console.WriteLine("\n Select an action! \n");
                        Console.WriteLine("Attack");
                        Console.WriteLine("Defend");
                        choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "Attack":

                                curState = CombatState.EnemyTurn;
                                break;
                            case "Defend":

                                curState = CombatState.EnemyTurn;
                                break;
                            default:
                                break;

                        }
                        break;
                    }
                    break;
                case CombatState.EnemyTurn:
                    Console.WriteLine("It is the enemy's turn");

                    break;
                case CombatState.Battleover:
                    working = false;
                    break;
                    
            }
           
 
        }
    }
}
