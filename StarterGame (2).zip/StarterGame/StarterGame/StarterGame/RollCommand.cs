﻿/*using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public class RollCommand : Command
    {
        public RollCommand() : base()
        {
            this.Name = "roll";
        }

        override
        public bool Execute(Player player)
        {
            if (this.HasSecondNumber())
            {
                player.Roll(this.SecondNumber);
            }
            else
            {
                player.OutputMessage("\nRoll What?");
            }
            return false;
        }
    }
}
*/