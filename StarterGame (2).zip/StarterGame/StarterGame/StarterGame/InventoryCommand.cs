﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public class InventoryCommand : Command
    {
        public InventoryCommand() : base()
        {
            this.Name = "inventory";
        }

        override
        public bool Execute(Player player)
        {
            if (this.HasSecondWord())
            {
                player.OutputMessage("\nI cannot inventory " + this.SecondWord);
            }
            else 
            {
                player.Invetory();
            }
            return false;
        }

    }
}
