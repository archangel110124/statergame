﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public interface IItem
    {
        string Name { get; set;}
        float Weight { get; set; }
        string Description { get; }
        bool IsContainer { get;}
        void AddItem(IItem item);
        IItem RemoveItem(string itemName);
    }
    public class Item : IItem
    { 
        public string Name { get; set; }
        public float Weight { get; set; }
        private string _description;
        public string Description { get { return "Name: " + Name + ", Weight: " + Weight + " " + _description; } }
        public bool IsContainer { get { return false; } }
        public Item() : this("nameless") { }

        public Item(string name) : this(name, 1.0f){}
        public Item(string name, float weight) : this(name, weight, "") { }
        // Designated Constructor
        public Item(string name, float weight, string description)
        {
            Name = name;
            Weight = weight;
            _description = description;
        }
        public void AddItem(IItem item)
        { 
            
        }
        public IItem RemoveItem(string itemName)
        {
            return null;
        }

    }
    public class ItemContainer : IItem
    {
        private Dictionary<string, IItem> _container;
        public string Name { get; set; }
        public float _weight { get; set; }
        public float Weight
        {
            get
            {
                float containedWeight = 0;
                foreach (IItem item in _container.Values)
                {
                    containedWeight += item.Weight;                
                }
                return containedWeight + _weight;
            }
            set 
            {
                _weight = value;            
            }
        }
        private string _description;
        public string Description 
        { 
            get 
            {
                string itemList = "Items: ";
                foreach (IItem item in _container.Values)
                {
                    itemList += "\n" + item.Description;
                }
                return "\nName: " + Name + "\nDescription: " + _description + "\nWeight: " + Weight + "\n" + itemList;
            } 
        }
        public ItemContainer() : this("container") { }

        public ItemContainer(string name) : this(name, 1.0f) { }
        public ItemContainer(string name, float weight) : this(name, weight, "") { }
        // Designated Constructor
        public ItemContainer(string name, float weight, string description)
        {
            _container = new Dictionary<string, IItem>();
            Name = name;
            Weight = weight;
           _description = description;
        }
        public bool IsContainer { get { return true; } }
        public void AddItem(IItem item)
        {
            _container[item.Name] = item;
        }
        public IItem RemoveItem(string itemName)
        {
            IItem item = null;
            _container.Remove(itemName, out item);
            return item;            
        }

    }
}
