﻿using System.Collections;
using System.Collections.Generic;
using System;

namespace StarterGame
{
    public class Room
    {
        private Dictionary<string, Door> exits;
        private string _tag;
        public string Tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
            }
        }
        private IItem _floor;
        private bool MonstersInRoom = false;
        private Monster _monsterInRoom;
        public void Drop(IItem item)
        {
            _floor.AddItem(item);
        }
        public IItem Pickup(string itemName)
        {
            IItem item = _floor.RemoveItem(itemName);
            return item;
        }
        public void addMonster(IMonster monster)
        {
            _monsterInRoom.AddMonster(monster);
            MonstersInRoom = true;
        }

        public Room() : this("No Tag")
        {

        }

        public Room(string tag)
        {
            _floor = new ItemContainer("Floor", 0f, "These are the items on the floor.");
            exits = new Dictionary<string, Door>();
            _monsterInRoom = new Monster("Monsters", 0, 0, 0, 0, "These are the monsters in the room.");
            this.Tag = tag;
        }

        public void SetExit(string exitName, Door door)
        {
            exits[exitName] = door;
        }

        public Door GetExit(string exitName)
        {
            Door door = null;
            exits.TryGetValue(exitName, out door);
            return door;
        }

        public string GetExits()
        {
            string exitNames = "Exits: ";
            Dictionary<string, Door>.KeyCollection keys = exits.Keys;
            foreach (string exitName in keys)
            {
                exitNames += " " + exitName;
            }

            return exitNames;
        }
        public string GetItems()
        {
            return _floor.Description;
        }

        public Monster GetMonsters()
        {

            return _monsterInRoom;
        }

        public string Description()
        {
            return "You are " + this.Tag + ".\n *** " + this.GetExits() + "\n ^^^ " + GetItems() + "\n~~~" + GetMonsters();
        }
    }
}
