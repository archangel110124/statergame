﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public class TBCombat
    {
        public enum CombatState { PlayerTurn, EnemyTurn, Battleover }
        public CombatState curState;
        public GameState curGameState;
        public IMonster monsterStats;
        public float _fPlayerHealth;
        public float _fPlayerAttack;
        public float _fPlayerDefense;
        public float _fPlayerDamage;

        public TBCombat(float fPlayerHealth, float fPlayerAttack, float fPlayerDefense, float fPlayerDamage, IMonster monster)
        {
            this._fPlayerHealth = fPlayerHealth;
            this._fPlayerAttack = fPlayerAttack;
            this._fPlayerDefense = fPlayerDefense;
            this._fPlayerDamage = fPlayerDamage;
            this.monsterStats = monster;
        }

        public void StartCombat()
        {
            // What are these?
            Console.WriteLine("You are being attacked by " + this.monsterStats.Name);
            bool working = true;
            string choice = "";
            bool bBattleOnGoing = true;
            bool isDefending = false;

            // INFINITE LOOP = BAD DESIGN (most of the time)
            while (bBattleOnGoing)
            {
                switch (curState)
                {

                    case CombatState.PlayerTurn:
                        while (working)
                        {
                            Console.WriteLine("Your health is " + this._fPlayerHealth);
                            Console.WriteLine("\n Select an action! \n");
                            Console.WriteLine("Attack");
                            Console.WriteLine("Defend");
                            choice = Console.ReadLine();
                            switch (choice)
                            {
                                case "Attack":
                                    monsterStats.Health -= this._fPlayerDamage;
                                    if (monsterStats.Health <= 0)
                                    {
                                        curState = CombatState.Battleover;
                                    }
                                    curState = CombatState.EnemyTurn;
                                    break;
                                case "Defend":
                                    isDefending = true;
                                    curState = CombatState.EnemyTurn;
                                    break;
                                default:
                                    break;

                            }
                            break;
                        }
                        break;
                    case CombatState.EnemyTurn:
                        Console.WriteLine("It is the enemy's turn");
                        // Enemy attacks here
                        if (isDefending)
                        {
                            monsterStats.Damage /= 2f;
                        }

                        this._fPlayerHealth -= monsterStats.Damage;
                        if (this._fPlayerHealth <= 0)
                        {
                            bBattleOnGoing = false;
                        }
                        curState = CombatState.PlayerTurn;

                        break;
                    case CombatState.Battleover:
                        bBattleOnGoing = false;
                        working = false;
                        isDefending = false;
                        break;

                }
            }

            if (this._fPlayerHealth > 0f) // alive
            {
                Console.Out.WriteLine("enemy defeated!");
            }
            else
            {
                Console.Out.WriteLine("You are dead");
            }

        }
        
    }
}