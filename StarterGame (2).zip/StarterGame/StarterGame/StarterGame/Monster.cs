﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StarterGame
{
    public interface IMonster
    {
        string Name { get; }
        float Health { get; set; }
        float Defense { get; set; }
        float Attack { get; set; }
        float Damage { get; set; }
        string Description { get; set; }
        void AddMonster(IMonster monster);
    }
    
    public class Monster : IMonster
    {
        public string _name;
        public string Name { get { return "Name: " + _name + ", Description: " +Description; } }
        public float Health { get; set; }
        public float Defense { get; set; }
        public float Attack { get; set; }
        public float Damage { get; set; }
        public string Description { get; set; } 
        public Monster(string name, float health, float defense, float attack, float damage, string description)
        {
            _name = name;
            Health = health;
            Defense = defense;
            Attack = attack;
            Damage = damage;
            Description = description;
        }
        public void AddMonster(IMonster monster)
        {

        }
    } 
}
